# terraform-provider-infoblox
terraform provider for infoblox ipam
